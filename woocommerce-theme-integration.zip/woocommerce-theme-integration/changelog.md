# WooCommerce Theme Integration Changelog

## 1.1.0, 20201119

### Add
- Featured Product block styling
- Active Filters block styling

### Update
- Styles

### Fixed
- Password reset procedure styles

### File updates
	changelog.md
	woocommerce-theme-integration.php
	assets/scss/woocommerce.scss


## 1.0.0, 20200804

- Initial release.
