# WooCommerce Theme Integration Changelog

## 1.0.0, 20200804

- Initial release.
